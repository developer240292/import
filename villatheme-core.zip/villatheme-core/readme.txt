=== VillaTheme Core ===
Contributors: villatheme
Donate link: http://www.villatheme.com/donate
Tags: villatheme, core, Redux, WooCommerce
Requires at least: 6.7
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: trunk
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The VillaTheme Core For WordPress Theme WooCommerce Shop.

== Installation ==

1. Unzip the download package
1. Upload `villatheme-core` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

/**1.0.0 - 2025.12.11**/
~ The first released
== Upgrade Notice ==