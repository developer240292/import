<?php
/**
 * Plugin Name: VillaTheme Core
 * Plugin URI: https://villatheme.com/
 * Description: The VillaTheme Core For WordPress Theme WooCommerce Shop.
 * Author: VillaTheme
 * Author URI: https://villatheme.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version: 1.0.0
 * Text Domain: villatheme-core
 * Requires at least: 6.7
 * Tested up to: 6.8
 * Requires PHP: 7.4
 */
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Villatheme_Core' ) ) {
	class  Villatheme_Core {
		/**
		 * @var Villatheme_Core The one true Villatheme_Core
		 * @since 1.0.0
		 */
		private static $instance;

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		private function setup() {
			$this->setup_constants();
			add_action( 'init', [ $this, 'load_textdomain' ] );
			add_action( 'plugins_loaded', [ $this, 'includes' ], 11 );
			add_action( 'after_setup_theme', [ $this, 'after_setup_theme' ] );
			add_action( 'upload_mimes', [ $this, 'add_file_types_to_uploads' ] );
			add_filter( 'script_loader_tag', [ $this, 'add_defer_attribute_to_js' ], 10, 3 );
			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ], 999 );
		}

		public function setup_constants() {
			// Plugin version.
			if ( ! defined( 'VILLATHEME_CORE_VERSION' ) ) {
				define( 'VILLATHEME_CORE_VERSION', '1.0.0' );
			}
			// Plugin Folder Path.
			if ( ! defined( 'VILLATHEME_CORE_PATH' ) ) {
				define( 'VILLATHEME_CORE_PATH', plugin_dir_path( __FILE__ ) );
			}
			// Plugin Folder URL.
			if ( ! defined( 'VILLATHEME_CORE_URL' ) ) {
				define( 'VILLATHEME_CORE_URL', plugin_dir_url( __FILE__ ) );
			}
		}

		public function after_setup_theme() {
			if ( class_exists( 'ReduxFramework' ) ) {
				require_once VILLATHEME_CORE_PATH . 'includes/footer-builder/footer-builder.php';
				require_once VILLATHEME_CORE_PATH . 'includes/megamenu/megamenu.php';
			}
		}

		public function includes() {
			require_once VILLATHEME_CORE_PATH . 'includes/widgets/abstracts-widget.php';
			require_once VILLATHEME_CORE_PATH . 'includes/widgets/widget-iconbox.php';
			require_once VILLATHEME_CORE_PATH . 'includes/widgets/widget-pofily.php';
			require_once VILLATHEME_CORE_PATH . 'includes/widgets/widget-post.php';
			require_once VILLATHEME_CORE_PATH . 'includes/widgets/widget-social.php';
			if ( $this->is_request( 'admin' ) ) {
				require_once VILLATHEME_CORE_PATH . 'includes/admin/dashboard.php';
				require_once VILLATHEME_CORE_PATH . 'includes/admin/plugins.php';
				if ( class_exists( 'OCDI_Plugin' ) ) {
					require_once VILLATHEME_CORE_PATH . 'includes/admin/one-click-demo-import.php';
				}
			}
			if ( $this->is_request( 'frontend' ) ) {
				require_once VILLATHEME_CORE_PATH . 'includes/frontend/shortcode.php';
			}
		}

		public function load_textdomain() {
			load_plugin_textdomain( 'villatheme-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		public function add_file_types_to_uploads( $file_types ) {
			$file_types['svg'] = 'image/svg+xml';

			return $file_types;
		}

		public function add_defer_attribute_to_js( $tag, $handle, $src ) {
			$defer_scripts = [
				'pofily-woo-product-filters-js-rangeSlide',
				'pofily-woo-product-filters-vi_dropdown',
				'pofily-woo-product-filters-off_canvas',
				'woo-coupon-box-script',
				'woo-notification',
				'vi-wpvs-frontend-script',
				'jquery-vi_flexslider',
				'woo-boost-sales',
				'woo-sctr-shortcode-script',
				'wcbwidget-shortcode-script',
				'yith-wcwl-add-to-wishlist',
				'yith-wcwl-add-to-wishlist-gutenberg',
				'jquery-selectBox',
				'jquery-yith-wcwl',
				'swv',
				'imagify-admin-bar',
				'yith-wcqv-frontend',
				'font-awesome',
				'megamenu-frontend',
				'popper',
				'tippy-bundle',
				'chosen',
				'slick',
				'jquery-scrollbar',
				'countdown',
				'draly-frontend',
			];
			if ( in_array( $handle, $defer_scripts, true ) ) {
				if ( false === strpos( $tag, 'defer' ) ) {
					$tag = str_replace( '<script ', '<script defer ', $tag );
				}
			}

			return $tag;
		}

		public function enqueue_admin_assets() {
			wp_enqueue_style( 'font-awesome', VILLATHEME_CORE_URL . 'assets/css/font-awesome.min.css' );
			wp_enqueue_style( 'villatheme-core-backend', VILLATHEME_CORE_URL . 'assets/css/backend.css' );
			wp_enqueue_script( 'villatheme-core-backend', VILLATHEME_CORE_URL . 'assets/js/backend.js', array(), null );
			wp_localize_script( 'villatheme-core-backend', 'villatheme_ajax_backend', array(
				'ajax_url' => admin_url( 'admin-ajax.php' )
			) );
		}

		public function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return function_exists( 'wp_doing_ajax' ) ? wp_doing_ajax() : defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
				case 'frontend':
					return ! is_admin() && ! defined( 'DOING_CRON' );
				default:
					return false;
			}
		}

		/**
		 * What is support elementor or not?
		 *
		 * @param string $type post_type or id.
		 *
		 * @return bool
		 */
		public function is_support_elementor( $type ) {
			$post_type   = is_numeric( $type ) ? get_post_type( $type ) : $type;
			$cpt_support = get_option( 'elementor_cpt_support', [ 'page', 'post' ] );

			if ( class_exists( 'Elementor\Plugin' ) && in_array( $post_type, $cpt_support ) ) {
				return true;
			}

			return false;
		}

		/**
		 * What is elementor or not?
		 *
		 * @param int $post_id post_type or id.
		 *
		 * @return bool
		 */
		public function is_elementor( $post_id ) {
			if ( class_exists( 'Elementor\Plugin' ) && $this->is_support_elementor( $post_id ) ) {
				if ( get_post_meta( $post_id, '_elementor_edit_mode', true ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * is Elementor editor?
		 *
		 * @return bool
		 */
		public function is_elementor_editor() {
			if ( class_exists( 'Elementor\Plugin' ) ) {
				if ( Elementor\Plugin::$instance->preview->is_preview_mode() || Elementor\Plugin::$instance->editor->is_edit_mode() ) {
					return true;
				}
			}

			return false;
		}
	}
}
if ( ! function_exists( 'VILLATHEME_CORE' ) ) {
	function VILLATHEME_CORE() {
		return Villatheme_Core::instance();
	}

	VILLATHEME_CORE();
}