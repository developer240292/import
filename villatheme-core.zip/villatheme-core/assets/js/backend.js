(function ($) {
    "use strict";
    $(document).ready(function () {
        //ocdi
        $('.js-ocdi-install-plugins-before-import').on('click', function(){
            let lastPct = 0;
            let delay = 100;
            const $wrap = $('<div id="villa-progress-wrap"><div id="villa-progress-bar"><span class="progress-active"></span><span class="progress-text">0%</span></div><div id="villa-progress-msg">Waiting to start import...</div></div>');
            $('.ocdi-importing').append($wrap);
            function updateUI(data){
               $('#villa-progress-bar .progress-active').css('width', data.percent + '%');
               $('#villa-progress-bar .progress-text').text(data.percent + '%');
               $('#villa-progress-msg').text(data.message);
            }
            function poll(){
                $.post(villatheme_ajax_backend.ajax_url, {
                    action: 'villa_import_progress'
                }).done(function(res){
                    if(res.success){
                        let pct = parseInt(res.data.percent, 10) || 0;
                        if (pct >= 10 && pct < 97) {
                            let inc = Math.floor(Math.random() * 4) + 2;
                            lastPct = Math.min(97, Math.max(10, lastPct + inc));
                            delay = 10000;
                        } else {
                            lastPct = pct;
                            delay = 100;
                        }
                        res.data.percent = lastPct;
                        updateUI(res.data);
                        setTimeout(poll, delay);
                    }
                });
            }
            poll();
        });
    });

})(jQuery);
