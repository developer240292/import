<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Villa_Import' ) ) {
	class Villa_Import {
		public function __construct() {
			add_filter( 'ocdi/plugin_page_setup', [ $this, 'plugin_page_setup' ] );
			add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
			add_action( 'ocdi/before_content_import', [ $this, 'before_content_import' ] );
			add_action( 'ocdi/before_widgets_import', [ $this, 'before_widgets_import' ] );
			add_action( 'ocdi/after_import', [ $this, 'after_import' ], 10 );
			add_filter( 'ocdi/import_successful_buttons', [ __CLASS__, 'import_successful_buttons' ] );
			add_action( 'wp_ajax_villa_import_progress', [ $this, 'villa_import_progress' ] );
			add_action( 'wp_ajax_nopriv_villa_import_progress', [ $this, 'villa_import_progress' ] );
		}

		public function plugin_page_setup( $settings ) {
			$settings['parent_slug'] = 'villa_dashboard';
			$settings['menu_title']  = __( 'Import Demo', 'villatheme-core' );
			$settings['page_title']  = __( 'Import Demo', 'villatheme-core' );
			$settings['capability']  = 'manage_options';
			$settings['menu_slug']   = 'villa_import';

			return $settings;
		}

		public function import_files() {
			$demos        = apply_filters( 'villa_import_demos', [] );
			$import_files = [];
			if ( ! empty( $demos ) ) {
				foreach ( $demos as $demo ) {
					$import_file_name = $demo['import_file_name'];
					$categories       = ! empty( $demo['categories'] ) ? $demo['categories'] : [];
					$demo_path        = $demo['demo_path'];
					$demo_uri         = ! empty( $demo['demo_uri'] ) ? $demo['demo_uri'] : '';
					$option_name      = ! empty( $demo['option_name'] ) ? $demo['option_name'] : '';
					$preview_url      = ! empty( $demo['preview_url'] ) ? $demo['preview_url'] : '';

					$import_file = [
						'import_file_name'       => $import_file_name,
						'categories'             => $categories,
						'demo_path'              => $demo_path,
						'import_file_url'        => $demo_path . 'content.xml',
						'import_widget_file_url' => $demo_path . 'widgets.wie',
						'preview_url'            => esc_url( $preview_url ),
					];
					if ( ! empty( $option_name ) ) {
						$import_file['import_redux'] = [
							[
								'file_url'   => $demo_path . 'redux',
								'option_name' => $option_name,
							],
						];
					} else {
						$import_file['import_customizer_file_url'] = $demo_path . 'customizer.dat';
					}
					if ( ! empty( $demo_uri ) ) {
						$import_file['import_preview_image_url'] = $demo_uri . 'preview.jpg';
					}
					if ( in_array( 'Placeholder Image', $categories ) ) {
						$import_file['import_file_url']        = $demo_path . 'content-placeholder.xml';
						if ( ! empty( $demo_uri ) ) {
							$import_file['import_preview_image_url'] = $demo_uri . 'preview-placeholder.jpg';
						}
					}
					$import_files[] = $import_file;
				}
			}

			return $import_files;
		}

		public function before_content_import() {
			set_transient( 'villa_import_progress', array(
				'percent' => 10,
				'message' => __( 'Downloading files...', 'villatheme-core' )
			), MINUTE_IN_SECONDS * 30 );
			update_option( 'permalink_structure', '/%postname%/' );
			// Delete old post, page, viwcpf_filter_block
			$posts = get_posts( [
				'post_type'      => [ 'post', 'page', 'viwcpf_filter_block' ],
				'post_status'    => 'any',
				'posts_per_page' => - 1,
				'fields'         => 'ids',
			] );
			foreach ( $posts as $post_id ) {
				wp_delete_post( $post_id, true );
			}
		}

		public function before_widgets_import() {
			wc_delete_product_transients();
			if ( ! wc_update_product_lookup_tables_is_running() ) {
				wc_update_product_lookup_tables();
			}
			$sidebars = wp_get_sidebars_widgets();
			if ( isset( $sidebars['widget-footer-1'] ) ) {
				$sidebars['widget-footer-1'] = [];
				wp_set_sidebars_widgets( $sidebars );
			}
			set_transient( 'villa_import_progress', array(
				'percent' => 97,
				'message' => __( 'Configuring site...', 'villatheme-core' )
			), MINUTE_IN_SECONDS * 5 );
		}

		public function after_import( $selected_import ) {
			$demo_path = $selected_import['demo_path'];
			// Update menu
			$primary_menu  = get_term_by( 'name', 'Primary Menu', 'nav_menu' );
			$vertical_menu = get_term_by( 'name', 'Vertical Menu', 'nav_menu' );
			$locations     = [];
			if ( $primary_menu ) {
				$locations['primary'] = $primary_menu->term_id;
			}
			if ( $vertical_menu ) {
				$locations['vertical_menu'] = $vertical_menu->term_id;
			}
			if ( ! empty( $locations ) ) {
				set_theme_mod( 'nav_menu_locations', $locations );
			}
			// Update Home, Blog
			$home_blog     = [ 'Home', 'Blog' ];
			$home_blog_map = [
				'Home' => 'page_on_front',
				'Blog' => 'page_for_posts'
			];
			$pages         = get_posts( [
				'post_type'              => 'page',
				'title'                  => $home_blog,
				'numberposts'            => - 1,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'fields'                 => 'ids',
			] );
			foreach ( $pages as $page_id ) {
				$page_title = get_the_title( $page_id );
				if ( isset( $home_blog_map[ $page_title ] ) ) {
					update_option( $home_blog_map[ $page_title ], $page_id );
				}
			}
			update_option( 'show_on_front', 'page' );
			//Update Comment Count
			global $wpdb;
			$post_ids = $wpdb->get_col( "SELECT DISTINCT comment_post_ID FROM $wpdb->comments" );
			foreach ( $post_ids as $post_id ) {
				wp_update_comment_count( $post_id );
			}
			// Update WooCommerce
			$woo_map = [
				'Shop'       => 'woocommerce_shop_page_id',
				'Cart'       => 'woocommerce_cart_page_id',
				'Checkout'   => 'woocommerce_checkout_page_id',
				'My account' => 'woocommerce_myaccount_page_id',
				'Wishlist'   => 'yith_wcwl_wishlist_page_id',
			];

			$pages = get_posts( [
				'post_type'              => 'page',
				'title'                  => array_keys( $woo_map ),
				'numberposts'            => - 1,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'fields'                 => 'ids',
			] );
			foreach ( $pages as $page_id ) {
				$page_title = get_the_title( $page_id );
				if ( isset( $woo_map[ $page_title ] ) ) {
					update_option( $woo_map[ $page_title ], $page_id );
				}
			}
			$plugin_options = [
				[
					'class'  => 'WOO_PRODUCT_COMPARE_ACTIVE',
					'file'   => 'compe-woo-compare-products.json',
					'option' => 'woo_product_compare_params',
				],
				[
					'class'  => 'VIWCPF_Woo_Product_Filters',
					'file'   => 'pofily-woo-product-filters.json',
					'option' => 'viwcpf_setting_params',
				],
				[
					'class'  => '\PSCWF\Inc\Frontend\Front_End',
					'file'   => 'product-size-chart-for-woo.json',
					'option' => 'woo_sc_setting',
				],
				[
					'class'  => 'VI_WOO_PRODUCT_VARIATIONS_SWATCHES',
					'file'   => 'product-variations-swatches-for-woocommerce.json',
					//"attribute_width": ["", "32", "60"] => "attribute_width": ["0", "32", "60"]
					//"attribute_height": ["", "32", "60"] => "attribute_height": ["0", "32", "60"]
					'option' => 'vi_woo_product_variation_swatches_params',
				],
				[
					'class'  => 'SALES_COUNTDOWN_TIMER',
					'file'   => 'sales-countdown-timer.json',
					'option' => 'sales_countdown_timer_params',
				],
				[
					'class'  => 'VARGAL_INIT',
					'file'   => 'vargal-additional-variation-gallery-for-woo.json',
					'option' => 'vargal_params',
				],
				[
					'class'  => 'VI_WOO_BOOSTSALES',
					'file'   => 'woo-boost-sales.json',
					'option' => '_woocommerce_boost_sales',
				],
				[
					'class'  => 'VI_WOO_COUPON_BOX_FREE',
					'file'   => 'woo-coupon-box.json',
					'option' => 'woo_coupon_box_params',
				],
				[
					'class'  => 'WFSPB_F_Shipping',
					'file'   => 'woo-free-shipping-bar.json',
					'option' => 'wfspb-param',
				],
				[
					'class'  => 'WOO_THANK_YOU_PAGE_CUSTOMIZER',
					'file'   => 'woo-thank-you-page-customizer.json',
					//"blocks": "[[[\"thank_you_message\",\"coupon\",\"order_confirmation\"]],[[\"order_details\"],[\"customer_information\",\"social_icons\"]],[[\"google_map\",\"order_again\"]]]",
					//"text_editor": "[]",
					//"products": "[]",
					'option' => 'woo_thank_you_page_params',
				],
				[
					'class'  => 'WOOMULTI_CURRENCY_F',
					'file'   => 'woo-multi-currency.json',
					'option' => 'woo_multi_currency_params',
				],
			];

			foreach ( $plugin_options as $plugin ) {
				if ( class_exists( $plugin['class'] ) ) {
					$file_path = $demo_path . $plugin['file'];
					if ( file_exists( $file_path ) && is_readable( $file_path ) ) {
						$data        = file_get_contents( $file_path );
						$parsed_data = json_decode( $data, true );
						update_option( $plugin['option'], $parsed_data );
					}
				}
			}

			if ( class_exists( '\PSCWF\Inc\Frontend\Front_End' ) ) {
				delete_option( 'pscw_setup_wizard' );
			}

			if ( class_exists( 'VIWCPF_Woo_Product_Filters_Public' ) ) {
				$filter_menu_default = get_page_by_path( 'preset-menu-filter-shop-page', OBJECT, 'viwcpf_filter_menu' );
				// Delete old viwcpf_filter_menu
				if ( ! empty( $filter_menu_default ) ) {
					wp_delete_post( $filter_menu_default->ID, true );
				}
				$slugs = apply_filters( 'villa_import_pofily', [] );
				if ( ! empty( $slugs ) ) {
					$filter_block = get_posts( [
						'post_type'      => 'viwcpf_filter_block',
						'post_status'    => 'any',
						'posts_per_page' => - 1,
						'fields'         => 'ids',
						'post_name__in'  => $slugs,
					] );
					$slug_to_id   = [];
					foreach ( $filter_block as $filter_block_id ) {
						$slug_to_id[ get_post_field( 'post_name', $filter_block_id ) ] = $filter_block_id;
					}
					$ordered_ids = [];
					foreach ( $slugs as $slug ) {
						if ( isset( $slug_to_id[ $slug ] ) ) {
							$ordered_ids[] = $slug_to_id[ $slug ];
						}
					}
					$filter_menu      = get_page_by_path( 'villa-filter', OBJECT, 'viwcpf_filter_menu' );
					$filter_menu_meta = array(
						'viwcpf_using_ajax'            => '',
						'viwcpf_show_button_submit'    => '1',
						'viwcpf_block_relation'        => 'AND',
						'viwcpf_show_in_modal'         => '',
						'viwcpf_show_reset_button'     => '',
						'viwcpf_reset_button_position' => 'before_filter',
						'viwcpf_display_conditions'    => array(
							array(
								'type'    => 'include',
								'archive' => 'all'
							)
						)
					);
					if ( ! empty( $ordered_ids ) && ! empty( $filter_menu ) ) {
						$filter_menu_meta['viwcpf_blocks_selected'] = implode( ',', $ordered_ids );
						update_post_meta( $filter_menu->ID, "viwcpf_filter_menu", $filter_menu_meta );
					}
				}
			} else {
				$sidebars = wp_get_sidebars_widgets();
				if ( isset( $sidebars['widget-shop'] ) ) {
					$sidebars['widget-shop'] = [];
					wp_set_sidebars_widgets( $sidebars );
				}
			}
			//Elementor Kit setup
			if ( did_action( 'elementor/loaded' ) ) {
				update_option( 'elementor_cpt_support', [ 'page', 'post', 'villa_footer', 'villa_menu' ] );
				update_option( 'elementor_disable_color_schemes', true );
				update_option( 'elementor_disable_typography_schemes', true );
				update_option( 'elementor_google_font', 0 );

				$elementor_json_file = $demo_path . 'elementor.json';
				$elementor_json_data = file_get_contents( $elementor_json_file );
				$elementor           = json_decode( $elementor_json_data, true );
				$kit                 = get_posts( [
					'post_type'      => 'elementor_library',
					'meta_key'       => '_elementor_template_type',
					'meta_value'     => 'kit',
					'posts_per_page' => 1,
				] );
				if ( empty( $kit ) ) {
					$kit_id = wp_insert_post( [
						'post_title'  => 'Imported Elementor Kit',
						'post_type'   => 'elementor_library',
						'post_status' => 'publish',
					] );
					update_post_meta( $kit_id, '_elementor_template_type', 'kit' );
				} else {
					$kit_id = $kit[0]->ID;
				}
				update_post_meta( (int) $kit_id, '_elementor_page_settings', $elementor['settings'] );
				update_option( 'elementor_active_kit', (int) $kit_id );

				$old_url = $selected_import['preview_url'];
				$new_url = home_url( '/' );
				\Elementor\Utils::replace_urls( $old_url, $new_url );

				\Elementor\Plugin::$instance->files_manager->clear_cache();
			}

			wc_delete_product_transients();
			if ( ! wc_update_product_lookup_tables_is_running() ) {
				wc_update_product_lookup_tables();
			}
			set_transient( 'villa_import_progress', array(
				'percent' => 100,
				'message' => __( 'Import finished.', 'villatheme-core' )
			), 10 );
			flush_rewrite_rules();
		}

		public static function import_successful_buttons() {
			$buttons = [
				[
					'label'  => __( 'Update Permalink Before Go To Shop Page', 'villatheme-core' ),
					'class'  => 'button button-primary button-hero',
					'href'   => admin_url( 'options-permalink.php' ),
					'target' => '_blank',
				]
			];

			return $buttons;
		}

		public function villa_import_progress() {
			$progress = get_transient( 'villa_import_progress' );
			if ( $progress === false ) {
				$progress = array(
					'percent' => 5,
					'message' => __( 'Starting import...', 'villatheme-core' )
				);
			}
			wp_send_json_success( $progress );
		}

	}

	new Villa_Import();
}
