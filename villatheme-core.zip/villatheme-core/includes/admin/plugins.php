<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( ! class_exists( 'Villa_Plugins' ) ) {
	class Villa_Plugins {
		public function __construct() {
			add_action( 'admin_menu', array( $this, 'admin_menu' ), 2 );
		}

		public function admin_menu() {
			if ( current_user_can( 'edit_theme_options' ) ) {
				add_submenu_page( 'villa_dashboard', 'Villa Plugins', 'Plugins', 'manage_options', 'villa_plugins', array(
					$this,
					'plugins'
				) );
			}
		}

		public function active_plugin() {
			if ( empty( $_GET['magic_token'] ) || wp_verify_nonce( $_GET['magic_token'], 'panel-plugins' ) === false ) {
				esc_html_e( 'Permission denied', 'villatheme-core' );
				die;
			}
			if ( isset( $_GET['plugin_slug'] ) && $_GET['plugin_slug'] != "" ) {
				$plugin_slug = $_GET['plugin_slug'];
				$plugins     = TGM_Plugin_Activation::$instance->plugins;
				foreach ( $plugins as $plugin ) {
					if ( $plugin['slug'] == $plugin_slug ) {
						activate_plugins( $plugin['file_path'] );
						?>
                        <script type="text/javascript">
                            window.location = "admin.php?page=villa_plugins";
                        </script>
						<?php
						break;
					}
				}
			}
		}

		public function deactivate_plugin() {
			if ( empty( $_GET['magic_token'] ) || wp_verify_nonce( $_GET['magic_token'], 'panel-plugins' ) === false ) {
				esc_html_e( 'Permission denied', 'villatheme-core' );
				die;
			}
			if ( isset( $_GET['plugin_slug'] ) && $_GET['plugin_slug'] != "" ) {
				$plugin_slug = $_GET['plugin_slug'];
				$plugins     = TGM_Plugin_Activation::$instance->plugins;
				foreach ( $plugins as $plugin ) {
					if ( $plugin['slug'] == $plugin_slug ) {
						deactivate_plugins( $plugin['file_path'] );
						?>
                        <script type="text/javascript">
                            window.location = "admin.php?page=villa_plugins";
                        </script>
						<?php
						break;
					}
				}
			}
		}

		public function plugins() {
			if ( ! class_exists( 'TGM_Plugin_Activation' ) ) {
				return;
			}
			if ( isset( $_GET['action'] ) && $_GET['action'] == 'deactivate_plugin' ) {
				$this->deactivate_plugin();
			}
			/* deactivate_plugin */
			if ( isset( $_GET['action'] ) && $_GET['action'] == 'active_plugin' ) {
				$this->active_plugin();
			}
			$villa_tgm_theme_plugins = TGM_Plugin_Activation::$instance->plugins;
			$tgm                     = TGM_Plugin_Activation::$instance;
			$wp_plugin_list          = get_plugins();

			// Handle bulk actions
			if ( isset( $_POST['villa_bulk_plugins_nonce'] ) && wp_verify_nonce( $_POST['villa_bulk_plugins_nonce'], 'villa_bulk_plugins_action' ) && ! empty( $_POST['selected_plugins'] ) && isset( $_POST['bulk_action'] ) && in_array( $_POST['bulk_action'], [
					'install',
					'activate',
					'deactivate'
				] ) ) {
				foreach ( $_POST['selected_plugins'] as $slug ) {
					if ( isset( $villa_tgm_theme_plugins[ $slug ] ) ) {
						$plugin    = $villa_tgm_theme_plugins[ $slug ];
						$file_path = $plugin['file_path'];

						switch ( $_POST['bulk_action'] ) {
							case 'install':
								if ( ! $tgm->is_plugin_installed( $slug ) ) {
									$tgm->install_plugins( [ $slug ] );
								}
								break;
							case 'activate':
								if ( isset( $wp_plugin_list[ $file_path ] ) && ! $tgm->is_plugin_active( $slug ) ) {
									activate_plugin( $file_path );
								}
								break;
							case 'deactivate':
								if ( is_plugin_active( $file_path ) ) {
									deactivate_plugins( $file_path );
								}
								break;
						}
					}
				}
				// Prevent form resubmission
				wp_redirect( admin_url( 'admin.php?page=villa_plugins' ) );
				exit;
			}
			?>

            <p><?php esc_html_e( 'Before importing the demo content ensure that you have Installed and Activated all the plugins', 'villatheme-core' ); ?></p>

            <form method="post">
                <table class="wp-list-table widefat striped">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'Plugin', 'villatheme-core' ) ?></th>
                        <th><?php esc_html_e( 'Type', 'villatheme-core' ) ?></th>
                        <th><?php esc_html_e( 'Action', 'villatheme-core' ) ?></th>
                    </tr>
                    </thead>
                    <tbody>
					<?php foreach ( $villa_tgm_theme_plugins as $plugin ) :
						$slug = $plugin['slug'];
						$file_path = $plugin['file_path'];
						if ( $tgm->is_plugin_active( $slug ) ) {
							if ( $slug == 'villatheme-core' ) {
								$status = '<span class="button button-secondary disabled">' . esc_html__( 'Deactivate', 'villatheme-core' ) . '</span>';
							} else {
								$status = '<a class="button button-secondary" href="' . esc_url( add_query_arg( array(
										'page'        => 'villa_plugins',
										'plugin_slug' => $slug,
										'action'      => 'deactivate_plugin',
										'magic_token' => wp_create_nonce( 'panel-plugins' ),
									), admin_url( 'admin.php' ) ) ) . '">' . esc_html__( 'Deactivate', 'villatheme-core' ) . '</a>';
							}
							if ( $tgm->does_plugin_have_update( $slug ) ) {
								$status = '<a class="button button-primary" href="' . esc_url( wp_nonce_url( add_query_arg( array(
										'page'         => urlencode( $tgm->menu ),
										'plugin'       => urlencode( $slug ),
										'tgmpa-update' => 'update-plugin',
									), $tgm->get_tgmpa_url() ), 'tgmpa-update', 'tgmpa-nonce' ) ) . '">' . esc_html__( 'Update', 'villatheme-core' ) . '</a>';
							}
						} elseif ( isset( $wp_plugin_list[ $file_path ] ) ) {
							$status = '<a class="button button-primary" href="' . esc_url( add_query_arg( array(
									'page'        => 'villa_plugins',
									'plugin_slug' => $slug,
									'action'      => 'active_plugin',
									'magic_token' => wp_create_nonce( 'panel-plugins' ),
								), admin_url( 'admin.php' ) ) ) . '">' . esc_html__( 'Activate', 'villatheme-core' ) . '</a>';
						} else {
							$status = '<a class="button button-primary" href="' . esc_url( wp_nonce_url( add_query_arg( array(
									'page'          => urlencode( $tgm->menu ),
									'plugin'        => urlencode( $slug ),
									'tgmpa-install' => 'install-plugin',
								), $tgm->get_tgmpa_url() ), 'tgmpa-install', 'tgmpa-nonce' ) ) . '">' . esc_html__( 'Install Now', 'villatheme-core' ) . '</a>';
						}
						?>
                        <tr>
                            <td><?php echo esc_html( $plugin['name'] ); ?></td>
                            <td><?php echo ! empty( $plugin['required'] ) ? esc_html__( 'Required', 'villatheme-core' ) : esc_html__( 'Recommended', 'villatheme-core' ); ?></td>
                            <td><?php echo wp_kses_post( $status ); ?></td>
                        </tr>
					<?php endforeach; ?>
                    </tbody>
                </table>
            </form>
			<?php
		}
	}

	new Villa_Plugins();
}
