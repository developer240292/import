<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_shortcode( 'current_year', 'villa_current_year_shortcode' );
if ( ! function_exists( 'villa_current_year_shortcode' ) ) {
	function villa_current_year_shortcode() {
		return esc_html( wp_date( 'Y' ) );
	}
}

add_shortcode( 'product_tag_cloud', 'villa_product_tag_cloud' );
function villa_product_tag_cloud( $atts ) {
	$defaults = [
		'smallest'   => 14,
		'largest'    => 14,
		'unit'       => 'px',
		'number'     => 12,
		'format'     => 'flat',
		'separator'  => "\n",
		'orderby'    => 'name',
		'order'      => 'ASC',
		'exclude'    => '',
		'include'    => '',
		'link'       => 'view',
		'taxonomy'   => 'product_tag',
		'post_type'  => '',
		'echo'       => false,
		'show_count' => 0,
	];
	$args     = shortcode_atts( $defaults, $atts );

	$args['smallest']   = (int) $args['smallest'];
	$args['largest']    = (int) $args['largest'];
	$args['number']     = (int) $args['number'];
	$args['show_count'] = (int) $args['show_count'];

	return wp_tag_cloud( $args );
}
