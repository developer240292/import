<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Villa Pofily
 *
 * Displays Pofily widget.
 *
 * @category Widgets
 * @package  Villa/Widgets
 * @version  1.0.0
 * @extends  Villa_Widget
 */
if ( ! class_exists( 'Villa_Pofily_Widget' ) ) {
	class Villa_Pofily_Widget extends Villa_Widget {
		/**
		 * Constructor.
		 */
		public function __construct() {
			$filter_menus = get_posts( array(
				'post_type'   => 'viwcpf_filter_menu',
				'post_status' => 'publish',
				'numberposts' => - 1,
				'orderby'     => 'title',
				'order'       => 'ASC',
			) );
			$options      = array();
			foreach ( $filter_menus as $menu ) {
				$options[ $menu->post_name ] = $menu->post_title;
			}
			$array_settings           = array(
				'title' => array(
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'villatheme-core' ),
				),
				'slug'  => array(
					'type'    => 'select',
					'options' => $options,
					'title'   => esc_html__( 'Filter Menus', 'villatheme-core' ),
				),
			);
			$this->widget_cssclass    = 'widget-villa-pofily';
			$this->widget_description = esc_html__( 'Display the pofily.', 'villatheme-core' );
			$this->widget_id          = 'widget_villa_pofily';
			$this->widget_name        = esc_html__( 'Villa: Pofily', 'villatheme-core' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @see WP_Widget
		 *
		 */
		public function widget( $args, $instance ) {
			$this->widget_start( $args, $instance );
			ob_start();
			$filter_menus_ids = get_posts( array(
				'post_type'      => 'viwcpf_filter_menu',
				'post_status'    => 'publish',
				'name'           => $instance['slug'],
				'fields'         => 'ids',
				'posts_per_page' => 1
			) );
			if ( ! empty( $filter_menus_ids ) ) {
				echo do_shortcode( '[VIWCPF_SHORTCODE id_menu="' . $filter_menus_ids[0] . '"]' );
			}
			$this->widget_end( $args );
		}
	}
}
add_action( 'widgets_init', 'Villa_Pofily_Widget' );
if ( ! function_exists( 'Villa_Pofily_Widget' ) ) {
	function Villa_Pofily_Widget() {
		register_widget( 'Villa_Pofily_Widget' );
	}
}