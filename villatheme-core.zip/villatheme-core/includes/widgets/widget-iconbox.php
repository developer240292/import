<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Villa_Iconbox_Widget' ) ) {
	class Villa_Iconbox_Widget extends Villa_Widget {
		/**
		 * Constructor.
		 */
		public function __construct() {
			$array_settings           = array(
				'title'    => array(
					'type'    => 'text',
					'title'   => esc_html__( 'Title:', 'villatheme-core' ),
					'default' => esc_html__( 'Iconbox', 'villatheme-core' ),
				),
				'heading1' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Iconbox 1:', 'villatheme-core' ),
				),
				'image1'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name1'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'desc1'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Description:', 'villatheme-core' ),
				),
				'heading2' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Iconbox 2:', 'villatheme-core' ),
				),
				'image2'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name2'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'desc2'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Description:', 'villatheme-core' ),
				),
				'heading3' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Iconbox 3:', 'villatheme-core' ),
				),
				'image3'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name3'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'desc3'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Description:', 'villatheme-core' ),
				),
				'heading4' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Iconbox 4:', 'villatheme-core' ),
				),
				'image4'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name4'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'desc4'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Description:', 'villatheme-core' ),
				),
				'heading5' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Iconbox 5:', 'villatheme-core' ),
				),
				'image5'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name5'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'desc5'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Description:', 'villatheme-core' ),
				),
			);
			$this->widget_cssclass    = 'widget-villa-iconbox';
			$this->widget_description = esc_html__( 'Display the Iconbox.', 'villatheme-core' );
			$this->widget_id          = 'widget_villa_iconbox';
			$this->widget_name        = esc_html__( 'Villa: Iconbox', 'villatheme-core' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @see WP_Widget
		 *
		 */
		public function widget( $args, $instance ) {
			$this->widget_start( $args, $instance );
			ob_start();
			?>
            <div class="iconbox-list">
                <div class="iconbox-item">
					<?php if ( ! empty( $instance['image1'] ) ) { ?>
                        <div class="iconbox-image">
                            <img src="<?php echo esc_url( $instance['image1'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
                        </div>
					<?php } ?>
					<?php if ( ! empty( $instance['name1'] ) ) { ?>
                        <h4 class="iconbox-name"><?php echo esc_html( $instance['name1'] ); ?></h4>
					<?php } ?>
					<?php if ( ! empty( $instance['desc1'] ) ) { ?>
                        <div class="iconbox-desc"><?php echo esc_html( $instance['desc1'] ); ?></div>
					<?php } ?>
                </div>
                <div class="iconbox-item">
					<?php if ( ! empty( $instance['image2'] ) ) { ?>
                        <div class="iconbox-image">
                            <img src="<?php echo esc_url( $instance['image2'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
                        </div>
					<?php } ?>
					<?php if ( ! empty( $instance['name2'] ) ) { ?>
                        <h4 class="iconbox-name"><?php echo esc_html( $instance['name2'] ); ?></h4>
					<?php } ?>
					<?php if ( ! empty( $instance['desc2'] ) ) { ?>
                        <div class="iconbox-desc"><?php echo esc_html( $instance['desc2'] ); ?></div>
					<?php } ?>
                </div>
                <div class="iconbox-item">
					<?php if ( ! empty( $instance['image3'] ) ) { ?>
                        <div class="iconbox-image">
                            <img src="<?php echo esc_url( $instance['image3'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
                        </div>
					<?php } ?>
					<?php if ( ! empty( $instance['name3'] ) ) { ?>
                        <h4 class="iconbox-name"><?php echo esc_html( $instance['name3'] ); ?></h4>
					<?php } ?>
					<?php if ( ! empty( $instance['desc3'] ) ) { ?>
                        <div class="iconbox-desc"><?php echo esc_html( $instance['desc3'] ); ?></div>
					<?php } ?>
                </div>
                <div class="iconbox-item">
					<?php if ( ! empty( $instance['image4'] ) ) { ?>
                        <div class="iconbox-image">
                            <img src="<?php echo esc_url( $instance['image4'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
                        </div>
					<?php } ?>
					<?php if ( ! empty( $instance['name4'] ) ) { ?>
                        <h4 class="iconbox-name"><?php echo esc_html( $instance['name4'] ); ?></h4>
					<?php } ?>
					<?php if ( ! empty( $instance['desc4'] ) ) { ?>
                        <div class="iconbox-desc"><?php echo esc_html( $instance['desc4'] ); ?></div>
					<?php } ?>
                </div>
                <div class="iconbox-item">
					<?php if ( ! empty( $instance['image5'] ) ) { ?>
                        <div class="iconbox-image">
                            <img src="<?php echo esc_url( $instance['image5'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
                        </div>
					<?php } ?>
					<?php if ( ! empty( $instance['name5'] ) ) { ?>
                        <h4 class="iconbox-name"><?php echo esc_html( $instance['name5'] ); ?></h4>
					<?php } ?>
					<?php if ( ! empty( $instance['desc5'] ) ) { ?>
                        <div class="iconbox-desc"><?php echo esc_html( $instance['desc5'] ); ?></div>
					<?php } ?>
                </div>
            </div>
			<?php
			echo ob_get_clean();
			$this->widget_end( $args );
		}
	}
}
add_action( 'widgets_init', 'Villa_Iconbox_Widget' );
if ( ! function_exists( 'Villa_Iconbox_Widget' ) ) {
	function Villa_Iconbox_Widget() {
		register_widget( 'Villa_Iconbox_Widget' );
	}
}