<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Villa_Social_Widget' ) ) {
	class Villa_Social_Widget extends Villa_Widget {
		/**
		 * Constructor.
		 */
		public function __construct() {
			$array_settings           = array(
				'title'    => array(
					'type'    => 'text',
					'title'   => esc_html__( 'Title:', 'villatheme-core' ),
					'default' => esc_html__( 'Follow us', 'villatheme-core' ),
				),
				'heading1' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 1:', 'villatheme-core' ),
				),
				'image1'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name1'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link1'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
				'heading2' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 2:', 'villatheme-core' ),
				),
				'image2'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name2'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link2'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
				'heading3' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 3:', 'villatheme-core' ),
				),
				'image3'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name3'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link3'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
				'heading4' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 4:', 'villatheme-core' ),
				),
				'image4'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name4'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link4'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
				'heading5' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 5:', 'villatheme-core' ),
				),
				'image5'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name5'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link5'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
				'heading6' => array(
					'type'  => 'heading',
					'title' => esc_html__( 'Social 6:', 'villatheme-core' ),
				),
				'image6'   => array(
					'type'  => 'image',
					'title' => esc_html__( 'Image:', 'villatheme-core' ),
				),
				'name6'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Name:', 'villatheme-core' ),
				),
				'link6'    => array(
					'type'  => 'text',
					'title' => esc_html__( 'Link:', 'villatheme-core' ),
				),
			);
			$this->widget_cssclass    = 'widget-villa-social';
			$this->widget_description = esc_html__( 'Display the Social.', 'villatheme-core' );
			$this->widget_id          = 'widget_villa_social';
			$this->widget_name        = esc_html__( 'Villa: Social', 'villatheme-core' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @see WP_Widget
		 *
		 */
		public function widget( $args, $instance ) {
			$this->widget_start( $args, $instance );
			ob_start();
			?>
            <div class="social-list">
				<?php if ( ! empty( $instance['link1'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link1'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image1'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image1'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name1'] ) ) { ?>
							<?php echo esc_html( $instance['name1'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
				<?php if ( ! empty( $instance['link2'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link2'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image2'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image2'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name2'] ) ) { ?>
							<?php echo esc_html( $instance['name2'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
				<?php if ( ! empty( $instance['link3'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link3'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image3'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image3'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name3'] ) ) { ?>
							<?php echo esc_html( $instance['name3'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
				<?php if ( ! empty( $instance['link4'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link4'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image4'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image4'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name4'] ) ) { ?>
							<?php echo esc_html( $instance['name4'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
				<?php if ( ! empty( $instance['link5'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link5'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image5'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image5'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name5'] ) ) { ?>
							<?php echo esc_html( $instance['name5'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
				<?php if ( ! empty( $instance['link6'] ) ) { ?>
                    <a href="<?php echo esc_url( $instance['link6'] ) ?>" class="social-item">
						<?php if ( ! empty( $instance['image6'] ) ) { ?>
                            <img src="<?php echo esc_url( $instance['image6'] ); ?>"
                                 alt="<?php echo esc_attr__( 'Image', 'villatheme-core' ); ?>"/>
						<?php } ?>
						<?php if ( ! empty( $instance['name6'] ) ) { ?>
							<?php echo esc_html( $instance['name6'] ); ?>
						<?php } ?>
                    </a>
				<?php } ?>
            </div>
			<?php
			echo wp_kses_post( ob_get_clean() );
			$this->widget_end( $args );
		}
	}
}
add_action( 'widgets_init', 'Villa_Social_Widget' );
if ( ! function_exists( 'Villa_Social_Widget' ) ) {
	function Villa_Social_Widget() {
		register_widget( 'Villa_Social_Widget' );
	}
}