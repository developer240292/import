<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Villa Post
 *
 * Displays Post widget.
 *
 * @category Widgets
 * @package  Villa/Widgets
 * @version  1.0.0
 * @extends  Villa_Widget
 */
if ( ! class_exists( 'Villa_Post_Widget' ) ) {
	class Villa_Post_Widget extends Villa_Widget {
		/**
		 * Constructor.
		 */
		public function __construct() {
			$array_settings           = array(
				'title'     => array(
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'villatheme-core' ),
				),
				'orderby'   => array(
					'type'    => 'select',
					'options' => array(
						'date'          => esc_html__( 'Date', 'villatheme-core' ),
						'ID'            => esc_html__( 'ID', 'villatheme-core' ),
						'author'        => esc_html__( 'Author', 'villatheme-core' ),
						'title'         => esc_html__( 'Title', 'villatheme-core' ),
						'modified'      => esc_html__( 'Modified', 'villatheme-core' ),
						'rand'          => esc_html__( 'Random', 'villatheme-core' ),
						'comment_count' => esc_html__( 'Comment count', 'villatheme-core' ),
						'menu_order'    => esc_html__( 'Menu order', 'villatheme-core' ),
					),
					'title'   => esc_html__( 'Orderby', 'villatheme-core' ),
				),
				'order'     => array(
					'type'    => 'select',
					'options' => array(
						'DESC' => esc_html__( 'DESC', 'villatheme-core' ),
						'ASC'  => esc_html__( 'ASC', 'villatheme-core' ),
					),
					'title'   => esc_html__( 'Order', 'villatheme-core' ),
				),
				'number'    => array(
					'type'    => 'number',
					'default' => 4,
					'title'   => esc_html__( 'Posts Per Page', 'villatheme-core' ),
				),
			);
			$this->widget_cssclass    = 'widget-villa-post';
			$this->widget_description = esc_html__( 'Display the customer Post.', 'villatheme-core' );
			$this->widget_id          = 'widget_villa_post';
			$this->widget_name        = esc_html__( 'Villa: Post', 'villatheme-core' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @see WP_Widget
		 *
		 */
		public function widget( $args, $instance ) {
			$this->widget_start( $args, $instance );
			ob_start();
			$args_loop = array(
				'post_type'           => 'post',
				'showposts'           => $instance['number'],
				'nopaging'            => 0,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => 1,
				'order'               => $instance['order'],
				'orderby'             => $instance['orderby'],
			);
			$loop_posts = new WP_Query( $args_loop );
			if ( $loop_posts->have_posts() ) : ?>
                <div class="villa-posts">
					<?php while ( $loop_posts->have_posts() ) : $loop_posts->the_post() ?>
                        <article <?php post_class(); ?>>
                            <div class="post-item-inner">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <div class="post-thumb">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php if ( ! empty( get_the_post_thumbnail() ) ) {
	                                            the_post_thumbnail( 'thumbnail' );
                                            } else { ?>
                                                <img src="<?php echo VILLATHEME_CORE_URL . '/assets/images/placeholder.jpg'; ?>"
                                                     alt="<?php echo esc_attr__( 'placeholder', 'villatheme-core' ); ?>">
                                            <?php } ?>
                                        </a>
                                    </div>
                                <?php endif;?>
                                <div class="post-info">
                                    <h4 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <div class="date"><?php echo get_the_date(); ?></div>
                                </div>
                            </div>
                        </article>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
                </div>
			<?php else :
				get_template_part( 'content', 'none' );
			endif;
			echo ob_get_clean();
			$this->widget_end( $args );
		}
	}
}
add_action( 'widgets_init', 'Villa_Post_Widget' );
if ( ! function_exists( 'Villa_Post_Widget' ) ) {
	function Villa_Post_Widget() {
		register_widget( 'Villa_Post_Widget' );
	}
}